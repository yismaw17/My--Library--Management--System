       My Library Management System
       
This is a web app used for library to manage book transaction and controll members. This is built using MERN stack. This is easy and friendly to use for all users.

   linkedin link --https://www.linkedin.com/feed/update/urn:li:activity:7074571529279139841?updateEntityUrn=urn%3Ali%3Afs_feedUpdate%3A%28V2%2Curn%3Ali%3Aactivity%3A7074571529279139841%29

Index
  -- Project title
  -- Introduction
  -- Installation
  -- Usage
  -- Technologies
  -- Contributing
  -- Related projects
  -- Author
  -- Licensing
  
Installation

frontend installation
1. Get into frontend directory
2. Run yarn to install independencies
3. Run yarn to start the app

backend installation
1. Get into backend directory
2. Run yarn to install independencies
3. Run nodemon server.js to start


Usage
   -- Showig event gallery
   -- Adding library members and books
   -- controlling transaction books
   
Technologies
   -- Express and NodeJS
   -- ReactJS
   -- MongoDB
   
contributing

Screen shot

Author
  -- leul kashay
  -- yismaw mulaw

licence
This is project licensed under MIT.
